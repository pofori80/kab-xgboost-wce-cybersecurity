KAB-XGBoost-WCE R05 -- Reproducibility Package
================================================
For supervisor: Dr. Eric Opoku Osei
Student: Prince Ofori (21990878), KNUST Ghana

Contents
--------
src/KAB_Option2_FourLegs_R05.py  -- Full evaluation pipeline (de-duplicated)
src/kab_xgboost_wce.py           -- Corrected weight function (Equation 2)
data/KNUST_Cybersecurity_Survey_Responses_2026.xlsx  -- Raw field data (n=4121)
data/Alzubaidi_2021_Cybercrime_Awareness_Dataset.xlsx -- Public dataset (n=1231)

How to run
----------
pip install xgboost scikit-learn scipy openpyxl pandas numpy
python src/KAB_Option2_FourLegs_R05.py

Key parameters (R05 locked)
----------------------------
KNUST de-duplicated: n=2088 (2033 exact duplicate response patterns removed)
WCE tuned: max_depth=3, lambda=1.5
Baseline XGBoost: max_depth=3 (independently tuned)
Seeds: 42, 1042, 2042, 3042, 4042
Protocol: 5 runs x 10-fold stratified CV = 50 paired estimates

KNUST R05 results (locked)
--------------------------
KAB-XGBoost-WCE : F1=0.6521 SD=0.0340
Baseline XGBoost: F1=0.6525 SD=0.0352
Wilcoxon W+=609.0 p=0.7888 (exact, no continuity correction)
Fold-win: 20/50 = 40.0%

Q19 root cause
--------------
2033 duplicate rows (49.3%) caused the submitted Decision Tree (0.9397)
and Random Forest (0.9497) anomaly. After de-duplication:
DT unlimited: 0.5638 (below baseline 0.6353).
Leakage mechanism: 50% of test rows had identical twins in training.

Notes
-----
KNUST data: restricted -- HuSSREC approval [INSERT REF]. Not for redistribution.
Alzubaidi data: CC BY-NC-ND 4.0. doi:10.17632/fbs9mgmh4y.3
